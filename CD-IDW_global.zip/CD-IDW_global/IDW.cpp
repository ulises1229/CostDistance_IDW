#include "IDW.h"
#include "common.h"
//------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------
void IDW::reset_Matrix(float **mat,int ROWS, int COLS,float val){
    for(int i=0; i<ROWS; i++)
        for(int j=0; j<COLS; j++)
            mat[i][j]=val;
}
//------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------
void IDW::sum_Matrix(float **resultado,float **mat2,int ROWS, int COLS){
    for(int i=0; i<ROWS; i++)
        for(int j=0; j<COLS; j++)
            if(mat2[i][j]>=0){
                resultado[i][j]+=mat2[i][j];
            }

}
//------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------
void IDW::localidades( float **loc_init, map <float, cell> &loc_map, int ROWS, int COLS, int val_null) {
    cell posicion;//se crea la estructura
    for (int i = 0; i < ROWS; i++)
        for (int j = 0; j < COLS; j++)
            if (loc_init[i][j] != val_null) {
                posicion.x = j;//guarda la posición en x de la localidad
                posicion.y = i;//guarda la posición en y de  la localidad
                loc_map.insert(pair<float, cell>(loc_init[i][j],posicion));//se guarda en el mapa, el no. de localidad como llave y la estructura con la ubicacion x y
            }
}
//------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------
int IDW::no_row(string name){
        int counter = 0;
        ifstream file(name.c_str());
        string data;
        while(getline(file,name))
            counter++;
        return counter;
    }
//------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------
void IDW::carga_requisitos(string name,map <int, float> &req_map){
    int cont;
    cont=no_row(name);
    ifstream file(name.c_str());
    stringstream buffer;
    buffer << file.rdbuf();
    string key;
    string val;
    while(cont>0) {
        getline(buffer,key,',');
        getline(buffer, val, '\n');
        req_map.insert(pair<int, float>(atof(key.c_str()),atof(val.c_str())));//se guarda en el mapa, el no. de localidad como llave y el requisito de biomasa
        cont--;
    }
}
//------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------
void IDW::IDW_cost_dist(float req,  int val_null, float **cost_dist, float **&final,float **&suma,int x_init, int y_init, int ROWS, int COLS, float exp){
    //--------------------------------------------------------------condiciones iniciales
    int total=1;
    int explorado=0;
    int fin=0;
    final[y_init][x_init]=0;//ubicación localidad
    map <int, cell> cost_map;
    map<int, cell >::iterator guardado;
    map<int, cell >::iterator actual;
    //------------------------------------------------------------------------------------------------------------------primera vez
    explorado+=movimientos(x_init, y_init,cost_dist,final,cost_map, ROWS ,COLS, val_null,explorado);
    guardado = cost_map.begin();
    while (total<=explorado){
        final[guardado->second.y][guardado->second.x]= req/pow( cost_dist[guardado->second.y][guardado->second.x],exp);
        suma[guardado->second.y][guardado->second.x]+=final[guardado->second.y][guardado->second.x];
        total++;
        guardado++;
    }
    guardado--;
    total--;
    actual = cost_map.begin();
    x_init = actual->second.x;
    y_init= actual->second.y;
    //------------------------------------------------------------------------------------------------------------------siguientes
    while(fin==0){
        explorado+=movimientos(x_init, y_init,cost_dist,final,cost_map, ROWS ,COLS, val_null,explorado);
        total++;
        guardado++;
        while (total<=explorado){
            final[guardado->second.y][guardado->second.x]= req/pow( cost_dist[guardado->second.y][guardado->second.x],exp);
            suma[guardado->second.y][guardado->second.x]+=final[guardado->second.y][guardado->second.x];
            total++;
            guardado++;
        }
        guardado--;
        total--;
        actual++;
        x_init = actual->second.x;
        y_init= actual->second.y;
        if(actual==guardado)
            fin=1;
    }
}
//------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------
int IDW::movimientos(int x, int y, float **mat, float **&final, map <int, cell> &map_opciones, int ROWS, int COLS, int val_null,int explorado){
	int x_tmp=0, y_tmp= 0;
	int cont=1;
    cell posicion;//se crea la estructura
	for(int mov=1; mov<=8; mov++ ){//son 8 los posibles movimientos que puede hacer
		switch(mov) { //para cada movimiento se guardan las coordenas temporales x y  aunque no sufran cambios
			case 1:
				x_tmp= x ;
				y_tmp=y+1;
				break;
			case 2:
				x_tmp= x -1;
				y_tmp= y+1;
				break;
			case 3:
				x_tmp= x  -1;
				y_tmp=y;
				break;
			case 4:
				x_tmp= x -1;
				y_tmp=y-1;
				break;
			case 5:
				x_tmp= x ;
				y_tmp=y-1;
				break;
			case 6:
				x_tmp= x +1;
				y_tmp=y-1;
				break;
            case 7:
                x_tmp=x +1;
                y_tmp=y;
                break;
            case 8:
                x_tmp= x  +1 ;
                y_tmp= y + 1;
                break;
			default:
				break;
		}
        if(x_tmp>0 && x_tmp<COLS && y_tmp>0 && y_tmp<ROWS && final[y_tmp][x_tmp]<0 && mat[y_tmp][x_tmp]!=val_null){//confirman que se pueda hacer el movimiento
            posicion.x = x_tmp;//guarda la posición en x del movimiento
            posicion.y = y_tmp;//guarda la posición en y del movimiento
            map_opciones.insert(pair<int, cell>(explorado+cont, posicion));//se guarda en el mapa, biomass o costo distancia como llave y la estructura con la ubicacion x y
            cont++;
        }
	}
	return (cont-1);
}