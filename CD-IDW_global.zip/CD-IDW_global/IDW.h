#include "common.h"
#ifndef VECTORIZED_MATRIX_VECTORIZED_H
#define VECTORIZED_MATRIX_VECTORIZED_H
#endif
typedef struct cell{
    int x;
    int y;
}
        cell;
class IDW{
public:

	void reset_Matrix(float **mat,  int ROWS,  int COLS, float val);
    void sum_Matrix(float **resultado,float **mat2, int ROWS,  int COLS);
    void localidades( float **loc_init,  map <float, cell> &loc_map, int ROWS,  int COLS, int val_null);
    int no_row(string name);
    void carga_requisitos(string name,map <int, float> &req_map);
    void IDW_cost_dist(float req, int val_null, float **cost_dist, float **&final,float **&suma,int x_init,  int y_init,  int ROWS,  int COLS, float exp);
    int movimientos(int x, int y, float **mat, float **&final, map <int, cell> &map_opciones , int ROWS, int COLS, int val_null, int explorado);
private:
};